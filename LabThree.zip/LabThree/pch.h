#ifndef PCH_H
#define PCH_H

#include <Ogre.h>
#include <OgreApplicationContext.h>
#include <OgreInput.h>
#include <SDL.h>
#include <iostream>
#include <OgreRTShaderSystem.h>
#include <OgreMath.h>

#endif